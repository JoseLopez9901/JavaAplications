package matriz.identidad;

import java.util.Random;
import java.util.Scanner;

public class MatrizIdentidad {

    public static void main(String[] args) {
        int filas, columnas;
        Scanner alm = new Scanner(System.in);
        System.out.println("Ingresa las filas de las matrices");
        filas = alm.nextInt();
        System.out.println("Ingresa las columnas de las matrices");
        columnas = alm.nextInt();

        int[][] matriz = new int[filas][columnas];
        Random r = new Random();

        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[i].length; j++) {
                matriz[i][j] = r.nextInt(25) + 1;
            }
            System.out.println();
        }
        if (filas == columnas) {
            for (int i = 0; i < matriz.length; i++) {
                for (int j = 0; j < matriz.length; j++) {
                    if (i == j) {
                        matriz[i][j] = 1;
                    } else {
                        matriz[i][j] = 0;
                    }
                }
            }
            System.out.println("Tu matriz identidad es: ");
            for (int i = 0; i < matriz.length; i++) {
                for (int j = 0; j < matriz[i].length; j++) {
                    System.out.println(matriz[i][j]+ " ");
                }
            }
        } else {
            System.out.println("Error");
        }
    }
}