package orden_mayor_menor_vicever;

import java.util.Scanner;

public class Orden_Mayor_Menor_Vicever {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int tamaño;

        System.out.println("Bienvenido\nPorfavor, Ingresa el tamaño de tu arreglo: \n");
        tamaño = teclado.nextInt();

        int arreglo[] = new int[tamaño];
        System.out.println("Porfavor, Ingresa los " + tamaño + " valores: ");

        for (int i = 0; i < tamaño; i++) {
            arreglo[i] = teclado.nextInt();

        }

        Scanner leer = new Scanner(System.in);
        int Opcion;

        System.out.println("Seleccione la accion a realizar\n");
        System.out.println("1) Ordenar de menor a mayor");
        System.out.println("2) Ordenar de mayor a menor");
        Opcion = leer.nextInt();
        switch (Opcion) {

            case 1:

                int a = 0;
                for (int j = 0; j < tamaño; j++) {
                    for (int i = 0; i < tamaño - 1; i++) {
                        if (arreglo[i] > arreglo[i + 1]) {
                            a = arreglo[i];
                            arreglo[i] = arreglo[i + 1];
                            arreglo[i + 1] = a;
                        }
                    }

                }
                int o = 0;
                System.out.println("Estos son tus " + tamaño + " valores ingresados ordenados de menor a mayor: \n");
                while (o < tamaño) {
                    System.out.println(arreglo[o]);
                    o++;
                }
                System.out.println("\n    ");
                break;
            
            case 2:

                int b = 0;
                for (int j = 0; j < tamaño; j++) {
                    for (int i = 0; i < tamaño - 1; i++) {
                        if (arreglo[i] > arreglo[i + 1]) {
                            b = arreglo[i];
                            arreglo[i] = arreglo[i + 1];
                            arreglo[i + 1] = b;
                        }
                    }

                }
                int or = 0;
                System.out.println("Estos son tus " + tamaño + " valores ingresados ordenados de mayor a menor: \n");
                while (or<tamaño) {
                    System.out.println(arreglo[or]);
                    or++;
                }
                System.out.println("\n    ");
                break;
        }
    }

}
