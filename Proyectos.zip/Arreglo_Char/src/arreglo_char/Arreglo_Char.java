/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package arreglo_char;

import java.util.Scanner;

/**
 *
 * @author Hp ENVY
 */
public class Arreglo_Char {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Scanner dat= new Scanner(System.in);
        String teclado="";
        System.out.println("Ingresa tu palabra: ");
        teclado=dat.nextLine();
        
        Char[] palabra = next Char[teclado.length()];
        palabra=teclado.toCharArray();
        
        for (int i = 0; i < teclado.length(); i++) {
            System.out.println("Posicion "+i+":" +palabra[i]);
            
        }
    }
    
}
