
package ejercicioarreglo;

import java.util.Scanner;


public class EjercicioArreglo {

    public static void main(String[] args) {
        int j;
        Scanner S = new Scanner(System.in);
        System.out.println("¿Cual sera el tamaño de tu arreglo?");
        j=S.nextInt();
        int a[]= new int[j];
        
        for (int i = 0; i < j; i++) {
            a[i]=(int)(Math.random()*10+1);
            System.out.println("Arreglo "+i+"="+a[i]);
        }
    }
    
}
