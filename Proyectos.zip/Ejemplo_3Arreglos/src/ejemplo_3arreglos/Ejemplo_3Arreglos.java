
package ejemplo_3arreglos;

import java.util.Scanner;


public class Ejemplo_3Arreglos {


    public static void main(String[] args) {
        Scanner dato = new Scanner(System.in);
        Scanner dato1 = new Scanner(System.in);
        Scanner dato2 = new Scanner(System.in);
    }
    
}
