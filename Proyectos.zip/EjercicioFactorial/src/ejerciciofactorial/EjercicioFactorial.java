
package ejerciciofactorial;
import java.util.Scanner;

public class EjercicioFactorial {

    
    public static void main(String[] args) {
        Scanner sc = new Scanner (System.in);
        System.out.println("Agrega un numero: ");
        int i = sc.nextInt();
        Factorial x = new Factorial();
        int x2;
        x2=x.fact(i);
        System.out.println("Su recursividad es: " +x2);
    }
    
}
