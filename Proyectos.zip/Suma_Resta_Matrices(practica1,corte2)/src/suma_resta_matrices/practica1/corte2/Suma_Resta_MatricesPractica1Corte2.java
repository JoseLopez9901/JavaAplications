package suma_resta_matrices.practica1.corte2;

import java.util.Random;
import java.util.Scanner;

public class Suma_Resta_MatricesPractica1Corte2 {

    public static void main(String[] args) {
        Scanner alm = new Scanner(System.in);
        int filas, columnas;
        System.out.println("Ingresa las filas de las matrices");
        filas = alm.nextInt();
        System.out.println("Ingresa las columnas de las matrices");
        columnas = alm.nextInt();
        Random r = new Random();

        int matriz1[][] = new int[filas][columnas];
        int matriz2[][] = new int[filas][columnas];
        int matrizResult[][] = new int[filas][columnas];

//Escribir datos en la matriz1
        System.out.println("Datos de la Matriz 1:");
        for (int i = 0; i < filas; i++) {
            for (int j = 0; j < columnas; j++) {
                matriz1[i][j] = r.nextInt(10) + 1;
                System.out.print(matriz1[i][j] + " ");
            }
            System.out.println();
        }

//Escribir datos en la matriz2
        System.out.println("Datos de la Matriz 2:");
        for (int i = 0; i < filas; i++) {
            for (int j = 0; j < columnas; j++) {
                matriz2[i][j] = r.nextInt(10) + 1;
                System.out.print(matriz2[i][j] + " ");
            }
            System.out.println();
        }
        System.out.println("Suma de las dos matrices: ");
        for (int i = 0; i < filas; i++) {
            for (int j = 0; j < columnas; j++) {
                matrizResult[i][j] = matriz1[i][j] + matriz2[i][j];
                System.out.print(matrizResult[i][j] + " ");
            }
            System.out.println();
        }

        System.out.println("Resta de las dos matrices: ");
        for (int i = 0; i < filas; i++) {
            for (int j = 0; j < columnas; j++) {
                matrizResult[i][j] = matriz1[i][j] - matriz2[i][j];
                System.out.print(matrizResult[i][j] + " ");
            }
            System.out.println();
        }
    }
}
