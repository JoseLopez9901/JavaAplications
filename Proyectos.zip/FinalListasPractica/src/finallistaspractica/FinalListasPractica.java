
package finallistaspractica;

import java.util.ArrayList;


public class FinalListasPractica {

    public static void main(String[] args) {
        CalculoListasFinal a = new CalculoListasFinal();
        ArrayList<Integer> array = a.LeerValores();
        double suma = a.Calculo(array);
        double media = suma / array.size();
        a.MostrarValores(array, suma, media);
    }
    
}
