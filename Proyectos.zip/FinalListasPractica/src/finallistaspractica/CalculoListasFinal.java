package finallistaspractica;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

public class CalculoListasFinal {

    public static ArrayList<Integer> LeerValores() {
        ArrayList<Integer> valores = new ArrayList();
        Scanner leer = new Scanner(System.in);

        int numero;
        System.out.println("Ingresa numero entero");
        System.out.println("\n(para finalizar preciona -00)");
        numero = leer.nextInt();
        while (numero != -00) {
            valores.add(numero);
            System.out.println("Ingresa numero entero");
            numero = leer.nextInt();
        }
        return valores;
    }

    public static double Calculo(ArrayList<Integer> valores) {
        double suma = 0;
        Iterator it = valores.iterator();
        while (it.hasNext()) {
            suma = suma + (Integer) it.next();
        }
        return suma;
    }

    public static void MostrarValores(ArrayList<Integer> valores, double suma, double media) {
    int cont=0;
        System.out.println("Valores introducidos: \n"+ valores);
        System.out.println("Suma: "+suma);
        System.out.println("Media: "+ media);
        for (Integer i : valores) {
            if (i>media) {
                cont++;
            }
        }
        System.out.println(cont +" valores superiores a la media");
    }
}
