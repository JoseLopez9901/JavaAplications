
package practica_matriz.por.puntualidad;

import java.util.Scanner;

public class Procedimientos {

    void matriz5xn() {
        Scanner sn=new Scanner(System.in);
         
        System.out.println("Escriba un numero de columnas");
        int columnas=sn.nextInt();
         
        int matriz[][]=new int[5][columnas];
         
        for(int i=0;i<matriz.length;i++){
            for(int j=0;j<matriz[0].length;j++){
                matriz[i][j]=generaNumAleatorio(0,9);
                System.out.print(matriz[i][j]+" ");
            }
            System.out.println("");
             
        }
         
    }
     
    public static int generaNumAleatorio(int minimo,int maximo){
         
        return (int)Math.floor(Math.random()*(minimo-(maximo+1))+(maximo+1));
         
    }
     
    void matriznxn() {
        Scanner sn=new Scanner(System.in);
         
        System.out.println("Escribe un tamaño");
        int tamanio=sn.nextInt();
         
        int matriz1[][]=new int[tamanio][tamanio];
        int matriz2[][]=new int[tamanio][tamanio];
         
        int resultado[][]=new int[tamanio][tamanio];
         
        for(int i=0;i<matriz1.length;i++){
            for(int j=0;j<matriz1[0].length;j++){
                 
                System.out.println("Escriba el valor para la fila "+i+" y columna "+j+" de la matriz 1");
                matriz1[i][j]=sn.nextInt();
                System.out.println("Escriba el valor para la fila "+i+" y columna "+j+" de la matriz 2");
                matriz2[i][j]=sn.nextInt();
                 
                resultado[i][j]=matriz1[i][j]+matriz2[i][j];
            }
        }
         
        System.out.println("Matriz 1");
        muestraMatriz(matriz1);
         
        System.out.println("Matriz 2");
        muestraMatriz(matriz2);
         
        System.out.println("Matriz resultante");
        muestraMatriz(resultado);
                 
    }
     
    public static void muestraMatriz(int[][] matriz){
     
        for(int i=0;i<matriz.length;i++){
            for(int j=0;j<matriz[0].length;j++){
                System.out.print(matriz[i][j]+" ");
            }
            System.out.println("");
        }
         
    }

    void matriz4x4enteros() {
        Scanner sn = new Scanner(System.in);
 
        //Matriz cuadrada de 4x4
        int matriz[][] = new int[4][4];
 
        //Variables utilizadas
        boolean salir = false;
        int opcion, fila, columna;
 
        //Utilizado para indicar si hemos entrado en la 1ª opcion
        boolean rellenado = false;
 
        //Menu
        do {
 
            //Mensajes del menu
            System.out.println("Menu");
            System.out.println("1. Rellenar Matriz");
            System.out.println("2. Sumar fila");
            System.out.println("3. Sumar columna");
            System.out.println("4. Suma diagonal principal");
            System.out.println("5. Suma diagonal inversa");
            System.out.println("6. Media elementos");
            System.out.println("7. Salir");
            System.out.println("Elije una opcion");
            opcion = sn.nextInt();
 
            switch (opcion) {
                case 1:
 
                    rellenarMatriz(sn, matriz);
 
                    //Ahora si podemos acceder al resto de opciones
                    rellenado = true;
 
                    break;
                case 2:
 
                    if (rellenado) {
 
                        //Validamos la fila
                        do {
 
                            System.out.println("Elige una fila");
                            fila = sn.nextInt();
 
                        } while (!(fila >= 0 && fila < matriz.length));
 
                        System.out.println("La suma de los valores de la fila " + fila
                                + " es: " + sumaFila(matriz, fila));
 
                    } else {
                        System.out.println("Debes rellenar la matriz primero");
                    }
 
                    break;
                case 3:
 
                    if (rellenado) {
 
                        //Validamos la colunma
                        do {
 
                            System.out.println("Elige una fila");
                            columna = sn.nextInt();
 
                        } while (!(columna >= 0 && columna < matriz.length));
 
                        System.out.println("La suma de los valores de la columna " + columna
                                + " es: " + sumaColumna(matriz, columna));
 
                    } else {
                        System.out.println("Debes rellenar la matriz primero");
                    }
 
                    break;
                case 4:
 
                    if (rellenado) {
 
                        System.out.println("La suma de la diagonal principal es: " + sumaDiagonalPrinc(matriz));
 
                    } else {
                        System.out.println("Debes rellenar la matriz primero");
                    }
 
                    break;
                case 5:
 
                    if (rellenado) {
 
                        System.out.println("La suma de la diagonal inversa es: " + sumaDiagonalInversa(matriz));
 
                    } else {
                        System.out.println("Debes rellenar la matriz primero");
                    }
 
                    break;
                case 6:
 
                    if (rellenado) {
 
                        System.out.println("La media de los valores de la "
                                + "matriz es de " + media(matriz));
 
                    } else {
                        System.out.println("Debes rellenar la matriz primero");
                    }
 
                    break;
                case 7:
                    salir = true;
                    break;
                default:
                    System.out.println("Tienes que meter un valor entre 1 y 7");
 
            }
 
        } while (!salir);
 
        System.out.println("FIN");
 
    }
 

    public static void rellenarMatriz(Scanner sn, int[][] matriz) {
 
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[0].length; j++) {
 
                System.out.println("Escribe un numero en la posicion " + i + " " + j);
                matriz[i][j] = sn.nextInt();
 
            }
        }
 
    }
 

    public static int sumaFila(int[][] matriz, int fila) {
 
        int suma = 0;
 
        for (int j = 0; j < matriz.length; j++) {
            suma += matriz[fila][j];
        }
 
        return suma;
 
    }
 

    public static int sumaColumna(int[][] matriz, int columna) {
 
        int suma = 0;
 
        for (int i = 0; i < matriz.length; i++) {
            suma += matriz[i][columna];
        }
 
        return suma;
 
    }
 

    public static int sumaDiagonalPrinc(int[][] matriz) {
 
        int suma = 0;
 
        for (int i = 0, j = 0; i < matriz.length; i++, j++) {
            suma += matriz[i][j];
        }
 
        return suma;
 
    }
 

    public static int sumaDiagonalInversa(int[][] matriz) {
 
        int suma = 0;
 
        for (int i = 0, j = 3; i < matriz.length; i++, j--) {
            suma += matriz[i][j];
        }
 
        return suma;
 
    }
 

    public static double media(int[][] matriz) {
 
        double suma = 0, media;
 
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[0].length; j++) {
                suma += matriz[i][j];
            }
        }
        media = suma / (matriz.length * matriz.length);
        return media;
 
    }
}

