package practica_matriz.por.puntualidad;
package proyect.pkg1.first.cut;
import java.util.Scanner;

public class Practica_matrizPorPuntualidad {

    public static void main(String[] args) {
        Scanner leer = new Scanner(System.in);
        int Opcion;
        
        System.out.println("Seleccione el tipo de ejercicio que quiere realizar");
        System.out.println("1) Crear una matriz de 3×3 con los números del 1 al 9");
        System.out.println("2) Crear una matriz de 5 filas y n columnas. Rellenarlo con números aleatorios entre 0 y 10.");
        System.out.println("3) Crear dos matrices de nxn y sumar sus valores");
        System.out.println("4) Crear una matriz de 4×4 de números enteros que inicialmente esta vacía.Con las especificaciones del ejercicio");
        Opcion = leer.nextInt();
        switch (Opcion) {

            case 1:
                int mat3x3[][] = new int[3][3];

                System.out.println("Tu matriz de 3x3 es: ");

                for (int i = 0; i < mat3x3.length; i++) {
                    for (int j = 0; j < mat3x3[0].length; j++) {
                        mat3x3[i][j] = (i * mat3x3.length) + (j + 1);

                        System.out.print(mat3x3[i][j] + " ");

                    }
                    System.out.println("");
                }
                System.out.println("\n    ");
                break;
            case 2:
        Procedimientos a = new Procedimientos();
        a.matriz5xn();
                break;
            case 3:
        Procedimientos b = new Procedimientos();
        b.matriznxn();
                break;
            case 4:
        Procedimientos c = new Procedimientos();
        c.matriz4x4enteros();
                break;
        }
    }

}