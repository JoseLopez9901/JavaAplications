package ordenarmayormenorviceversa;

import java.util.Arrays;
import java.util.Scanner;

public class OrdenarMayorMenorViceversa {

    public static void main(String[] args) {
        Scanner repeat = new Scanner(System.in);
        int s;

        Scanner teclado = new Scanner(System.in);
        int tamaño;
        do {
            System.out.println("Bienvenido\nPorfavor, Ingresa el tamaño de tu arreglo:");
            tamaño = teclado.nextInt();

            int numeros[] = new int[tamaño];
            System.out.println("Porfavor, Ingresa los " + tamaño + " valores: ");

            for (int i = 0; i < tamaño; i++) {
                numeros[i] = teclado.nextInt();

            }

            Scanner leer = new Scanner(System.in);
            int Opcion;

            System.out.println("Seleccione la accion a realizar\n");
            System.out.println("1) Ordenar de menor a mayor");
            System.out.println("2) Ordenar de mayor a menor");
            System.out.println("3) Ambas");
            System.out.println("\n    ");
            Opcion = leer.nextInt();
            switch (Opcion) {
                case 1:
                    Arrays.sort(numeros);
                    for (int i = 0; i < numeros.length; i++) {
                        System.out.println("" + numeros[i]);
                    }
                    System.out.println("\n    ");
                    break;
                case 2:
                    Arrays.sort(numeros);
                    for (int i = numeros.length - 1; i >= 0; i--) {
                        System.out.println("" + numeros[i]);
                    }
                    System.out.println("\n    ");
                    break;
                case 3:
                    Arrays.sort(numeros);
                    System.out.println("Menor a Mayor");
                    for (int i = 0; i < numeros.length; i++) {
                        System.out.println("" + numeros[i]);
                    }
                    Arrays.sort(numeros);
                    System.out.println("Mayor a Menor");
                    for (int i = numeros.length - 1; i >= 0; i--) {
                        System.out.println("" + numeros[i]);
                    }
                    System.out.println("\n    ");
                    break;
            }
            System.out.println("¿Desea repetir el ejercicio? \n");
            System.out.println("1) Si");
            System.out.println("2) No");
            s = repeat.nextInt();
        } while (s == 1);
    }
}
