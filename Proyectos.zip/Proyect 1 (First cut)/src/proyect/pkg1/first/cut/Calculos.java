
package proyect.pkg1.first.cut;

import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Random;
import java.util.Scanner;



public class Calculos {
    Scanner rea = new Scanner(System.in); 
    Scanner read = new Scanner(System.in); 
    Scanner read1 = new Scanner(System.in);
    Scanner repeat= new Scanner(System.in);
    //Variables para tramite CURP/RFC
    String nombre, appaterno, apmaterno, año, mes, dia, rfc, curp, genero, entidad;
    int Op,Op1,s;
    Random OwO = new Random();
    //Variables para el calculo de edad
    Scanner ed= new Scanner (System.in);
    Calendar cal = new GregorianCalendar(2022,01,31);
    int mesAct=cal.get(Calendar.MONTH), añoAct=cal.get(Calendar.YEAR), diaAct=cal.get(Calendar.DAY_OF_MONTH);
    int mess, diaa, añoo;
    int mesRes, diaRes, añoRes;
    
    
    
    void Tramite(){
        do{
        System.out.println("¿Que tramite realizará?");
                    System.out.println("1) RFC");
                    System.out.println("2) CURP");
                    System.out.println("3) CALCULA TU EDAD");
                    Op=rea.nextInt();
        switch (Op){
            case 1:
                System.out.println("Usted tramitara su RFC, favor ingresar los datos requeridos");
                System.out.println("\n    ");
                
                System.out.println("Ingresa tu(s) nombre(s)");
                        nombre= read.nextLine();
                    System.out.println("Ingresa tu apellido paterno");
                        appaterno= read.nextLine();
                    System.out.println("Ingresa tu apellido materno");
                        apmaterno= read.nextLine();
                    System.out.println("Ingresa tu año de nacimiento");
                        año= read.nextLine();
                    System.out.println("Ingresa tu mes de nacimiento \n(ejemplo: 01,02,03..12)");
                        mes= read.nextLine();
                    System.out.println("Ingresa tu dia de nacimiento");
                        dia= read.nextLine();
                        
                rfc = appaterno.trim().substring(0, 2);
                rfc = rfc.concat(apmaterno.trim().substring(0, 1));
                rfc = rfc.concat(nombre.trim().substring(0, 1));
                rfc = rfc.concat(año.trim().substring(2, 4));
                rfc = rfc.concat(mes.trim().substring(0, 1));
                rfc = rfc.concat(dia.trim().substring(0, 2));
                rfc = rfc.concat(dia.trim().substring(0, 1));
                rfc = rfc.concat(apmaterno.trim().substring(2, 4));
                        System.out.println("Tu RFC es: "+rfc+OwO.nextInt(3)+1);
                        System.out.println("\n    ");    
        break;
        
            case 2:
                System.out.println("Usted tramitara su CURP, favor ingresar los datos requeridos");
                System.out.println("\n    ");
                    
                System.out.println("Ingresa tu(s) nombre(s)");
                        nombre= read.nextLine();
                    System.out.println("Ingresa tu apellido paterno");
                        appaterno= read.nextLine();
                    System.out.println("Ingresa tu apellido materno");
                        apmaterno= read.nextLine();
                    System.out.println("Ingresa tu año de nacimiento");
                        año= read.nextLine();
                    System.out.println("Ingresa tu mes de nacimiento \n(ejemplo: 01,02,03..12)");
                        mes= read.nextLine();
                    System.out.println("Ingresa tu dia de nacimiento");
                        dia= read.nextLine();
                    System.out.println("Ingresa tu Genero Hombre/Mujer");
                        genero= read.nextLine();    
                    System.out.println("Ingresa Entidad de Nacimiento");
                        System.out.println("1) Aguascalientes");
                        System.out.println("2) Baja California");
                        System.out.println("3) Baja California Sur");
                        System.out.println("4) Campeche");
                        System.out.println("5) Chiapas");
                        System.out.println("6) Chihuahua");
                        System.out.println("7) Coahuila");
                        System.out.println("8) Colima");
                        System.out.println("9) Distrito Federal");
                        System.out.println("10) Durango");
                        System.out.println("11) Guanajuato");
                        System.out.println("12) Guerrero");
                        System.out.println("13) Hidalgo");
                        System.out.println("14) Jalisco");
                        System.out.println("15) Estado de Mexico");
                        System.out.println("16) Michoacan");
                        System.out.println("17) Morelos");
                        System.out.println("18) Nayarit");
                        System.out.println("19) Nuevoleon");
                        System.out.println("20) Oaxaca");
                        System.out.println("21) Puebla");
                        System.out.println("22) Queretaro");
                        System.out.println("23) Quintana Roo");
                        System.out.println("24) San Luis Potosí");
                        System.out.println("25) Sinaloa");
                        System.out.println("26) Sonora");
                        System.out.println("27) Tabasco");
                        System.out.println("28) Tamaulipas");
                        System.out.println("29) Tlaxcala");
                        System.out.println("30) Veracruz");
                        System.out.println("31) Yucatan");
                        System.out.println("32) Zacatecas");
                    entidad= read.nextLine();
                    
                    switch (entidad){
                        case "1": entidad = "AS"; break;
                        case "2": entidad = "BC"; break;
                        case "3": entidad = "BS"; break;
                        case "4": entidad = "CC"; break;
                        case "5": entidad = "CS"; break;
                        case "6": entidad = "CH"; break;
                        case "7": entidad = "CL"; break;
                        case "8": entidad = "CM"; break;
                        case "9": entidad = "DF"; break;
                        case "10": entidad = "DG"; break;
                        case "11": entidad = "GT"; break;
                        case "12": entidad = "GR"; break;
                        case "13": entidad = "HG"; break;
                        case "14": entidad = "JC"; break;
                        case "15": entidad = "MC"; break;
                        case "16": entidad = "MN"; break;
                        case "17": entidad = "MS"; break;
                        case "18": entidad = "NT"; break;
                        case "19": entidad = "NL"; break;
                        case "20": entidad = "OC"; break;
                        case "21": entidad = "PL"; break;
                        case "22": entidad = "QO"; break;
                        case "23": entidad = "QR"; break;
                        case "24": entidad = "SP"; break;
                        case "25": entidad = "SL"; break;
                        case "26": entidad = "SR"; break;
                        case "27": entidad = "TC"; break;
                        case "28": entidad = "TS"; break;
                        case "29": entidad = "TL"; break;
                        case "30": entidad = "VZ"; break;
                        case "31": entidad = "YN"; break;
                        case "32": entidad = "ZS"; break;  
                    } 
                    
                        
                curp = appaterno.trim().substring(0, 2);
                curp = curp.concat(apmaterno.trim().substring(0, 1));
                curp = curp.concat(nombre.trim().substring(0, 1));
                curp = curp.concat(año.trim().substring(2, 4));
                curp = curp.concat(mes.trim().substring(0, 1));
                curp = curp.concat(dia.trim().substring(0, 2));
                curp = curp.concat(dia.trim().substring(0, 1));
                curp = curp.concat(genero.trim().substring(0, 1));
                curp = curp.concat(entidad);
                curp = curp.concat(appaterno.trim().substring(2, 3));
                curp = curp.concat(apmaterno.trim().substring(2, 3));
                curp = curp.concat(appaterno.trim().substring(0, 1));
                
                        System.out.println("Tu CURP es: "+curp+0+10/2);
                        System.out.println("\n    "); 
        break;
            case 3:
                    try{
                    System.out.println("Usted consultara su edad, porfavor ingrese los siguientes valores");
                    System.out.println("\n    ");
                    
                    System.out.println("Ingresa dia de nacimiento");
                        diaa=ed.nextInt();
                    System.out.println("Ingresa mes de nacimiento \n(ejemplo: 01,02,03..12)");
                        mess=ed.nextInt();
                    System.out.println("Ingresa año de nacimiento");
                        añoo=ed.nextInt();
                        
                        if (diaa<0 | diaa >31) {
                            throw new Exception ("Error en el dia");
                        }
                        if (mess<0 | mess >12) {
                            throw new Exception ("Error en el dia");
                        }
                        if (añoo<0) {
                            throw new Exception ("Error en el dia");
                        }
                        
                    añoRes = Math.abs(añoo-añoAct);
                    
                    System.out.println("Tienes "+añoRes+ "años");
                    System.out.println("\n    "); 
                    
                    }catch(Exception ex){
                        System.out.println("Error "+ex.toString());
                    }
            }
        
        
                    System.out.println("¿Desea hacer otro tramite?");
                    System.out.println("1) Si");
                    System.out.println("2) No");
                    System.out.println("\n    "); 
                    s=repeat.nextInt();
        } while (s==1);
    }
}
