
package proyect.pkg1.first.cut;

public class Proyect1FirstCut {

    public static void main(String[] args) {
        
        System.out.println("Bienvenido!! \n         ");
        
        Calculos a = new Calculos();
        a.Tramite();   
    }
}