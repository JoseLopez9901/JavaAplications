
package ejercicioarreglo2;

import java.util.Scanner;


public class EjercicioArreglo2 {

    
    public static void main(String[] args) {
        Scanner dat= new Scanner(System.in);
        Scanner dat2= new Scanner(System.in);
        int tam1,tam2,s;
        
        do{
            System.out.println("¿Cual sera el tamaño de tu arreglo 1?");
                tam1=dat.nextInt();
                    int arreglo1[]= new int [tam1];
            System.out.println("¿Cual sera el tamaño de tu arreglo 2?");
                tam2=dat.nextInt();
                    int arreglo2[]= new int [tam2];            
                
            if(tam1==tam2) {
                int op;
                int [] arreglo3 = new int [tam1];
                
                for (int i = 0; i < tam1; i++) {
                    arreglo1[i]=(int) (Math.random()*20)+1;
                    arreglo2[i]=(int) (Math.random()*20)+1;
                }
                
                System.out.println("Arreglo 1");
                for (int i = 0; i < tam1; i++) {
                    System.out.println("Posicion " +(i+i)+": " +arreglo1[i]);
                }
                System.out.println("Arreglo 2");
                for (int i = 0; i < tam1; i++) {
                    System.out.println("Posicion " +(i+i)+": " +arreglo2[i]);
                }
                
                System.out.println("Elige una opcion");
                    System.out.println("1) Suma");
                    System.out.println("2) Resta");
                    System.out.println("3) Multiplicacion");
                    System.out.println("4) Divicion");
                System.out.println("Opcion: ");
                op=dat.nextInt();
                
                switch (op){
                    case 1:
                        System.out.println("Arreglo 3");
                            for (int i = 0; i < tam1; i++) {
                                arreglo3[i]= arreglo1[i]+arreglo2[i];
                                System.out.println("Posicion " +(i+1)+": " +arreglo3[i]);
                        } break;
                    case 2:
                        System.out.println("Arreglo 3");
                            for (int i = 0; i < tam1; i++) {
                                arreglo3[i]= arreglo1[i]-arreglo2[i];
                                System.out.println("Posicion " +(i+1)+": " +arreglo3[i]);
                        } break;
                    case 3:
                        System.out.println("Arreglo 3");
                            for (int i = 0; i < tam1; i++) {
                                arreglo3[i]= arreglo1[i]*arreglo2[i];
                                System.out.println("Posicion " +(i+1)+": " +arreglo3[i]);
                        } break;
                    case 4:
                        System.out.println("Arreglo 3");
                            for (int i = 0; i < tam1; i++) {
                                arreglo3[i]= arreglo1[i]/arreglo2[i];
                                System.out.println("Posicion " +(i+1)+": " +arreglo3[i]);
                        } break;
                } 
                
                } else {
                    System.out.println("Lo sentimos, son diferentes tamaños, no podemos resolverlo");
                }
                
                
                    System.out.println("¿Quiere intentarlo de nuevo?");
                    System.out.println("1) Si");
                    System.out.println("2) No");
                    s=dat2.nextInt();
                    
             
        } while (s==1);
        
    }
    
}
