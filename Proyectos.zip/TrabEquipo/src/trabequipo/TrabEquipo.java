
package trabequipo;

import java.util.Scanner;


public class TrabEquipo {

    
    public static void main(String[] args) {
       Scanner d= new Scanner(System.in);
        String Nombre=" ";
        String Ap=" ";
        String Am=" ";
        int decision=1;
            do{
            //Nombre
                Scanner dato= new Scanner(System.in);
                System.out.println("Ingresa tu Nombre: ");
                    Nombre=dato.nextLine();
        
                    char[] arreglo= new char[Nombre.length()];
                        arreglo=Nombre.toCharArray();
            
                //Apellido paterno
                Scanner dato1= new Scanner(System.in);
                System.out.println("Ingresa tu Apellido Paterno: ");
                    Ap=dato1.nextLine();
        
                    char[] arreglo1= new char[Ap.length()];
                        arreglo1=Ap.toCharArray();
        
                //Ingresa apellido materno
                Scanner dato2= new Scanner(System.in);
                System.out.println("Ingresa tu Apellido Materno: ");
                    Am=dato2.nextLine();
        
                    char[] arreglo2= new char[Am.length()];
                        arreglo2=Am.toCharArray();
        
                //Imprimir todo el nombre 
                System.out.println("Cadena completa: "+Nombre+" "+Ap+" "+Am);
        
                //Primer letra de apellido paterno
                char firstCharacter = Ap.charAt(0);
                System.out.print( firstCharacter);
        
                //Vocal interna
                for (int i = 0; i < arreglo1.length; i++) {
                        if (arreglo1[i]=='a'||arreglo1[i]=='e'||arreglo1[i]=='i'||arreglo1[i]=='o'||arreglo1[i]=='u'){
                        System.out.print(arreglo1[i]);    
                      break;}
                     }
        
                //Primera letra de apellido materno
                char firstCharacter3 = Am.charAt(0);
                    System.out.print(firstCharacter3);
        
                //Primera letra de nombre
                char firstCharacter4 = Nombre.charAt(0);
                    System.out.println(firstCharacter4);

            System.out.println("Deseas repetir el programa? ");
            System.out.println("1)Si");
            System.out.println("2)No ");
            decision=d.nextInt();
            
            }while(decision==1);           
    }
}
