
package modelo;

import com.mysql.jdbc.Connection;
import java.net.URL;
import java.sql.DriverManager;
import javax.swing.JOptionPane;


public class Conexion {
    private final String base = "universidad";
    private final String user = "root";
    private final String password = "990111";
    private final String url = "jdbc:mysql://localhost:3306/" +base;
    
    public Connection getConexion()
    {
        Connection con = null;

        try {

            Class.forName("com.mysql.jdbc.Driver");
            con = (Connection) DriverManager.getConnection(url, user, password);
            JOptionPane.showMessageDialog(null, "Conexion exitosa");

        } catch (Exception e) {
            System.out.println(e);
        }
        return con;
    }


}
