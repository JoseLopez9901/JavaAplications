
package modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;


public class SQL_Usuarios extends Conexion {
    
    public boolean registar(usuarios usr)
    {
        PreparedStatement ps= null;
        Connection con= getConexion();
        
        String sql="INSERT INTO usuarios (usuario, password, nombre, id_tipo) values (?,?,?,?)";
        try{
        ps= con.prepareStatement(sql);
        ps.setString(1, usr.getUsuario());
        ps.setString(2, usr.getPassword());
        ps.setString(3, usr.getNombre());
        ps.setInt(4, usr.getId_tipo());
        
        ps.execute();
        return true;
        
        
        }catch(Exception e){
            System.err.println(e);
            return false;
        }
    }
}
