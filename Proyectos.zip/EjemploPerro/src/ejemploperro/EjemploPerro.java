
package ejemploperro;

public class EjemploPerro {

    
    public static void main(String[] args) {
        Perro a = new Perro();
        a.ladrar("Guau guau");
        a.orinar();
    }
    
}
