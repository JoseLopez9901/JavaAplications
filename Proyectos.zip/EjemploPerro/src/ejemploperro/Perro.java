
package ejemploperro;


public class Perro {
    String Nombre;
    String Raza;
    int Edad;
    String Genero;
    
    
    void ladrar(String l) {
        System.out.println("Grrrr!!! "+l+"");
    }
    void orinar(){
        System.out.println("Se orina*");
    }
    
}
