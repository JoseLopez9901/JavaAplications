
package tienda;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;



public class ADMIN extends javax.swing.JFrame {
    DefaultTableModel modelo = new DefaultTableModel();
    DefaultTableModel modelos = new DefaultTableModel();
    DefaultTableModel model=new DefaultTableModel();
    
    private static Connection conectar;
    
    private static final String driver="com.mysql.jdbc.Driver";
    private static final String user="root";
    private static final String pass="990111";
    private static final String url="jdbc:mysql://localhost:3306/tiendav";
    
    
    
    public void conector() {
        
        conectar=null;
        try{
            Class.forName(driver);
            
            conectar= (Connection) DriverManager.getConnection(url, user, pass);
            
            if (conectar!=null){
                label1.setText("Conexion establecida");
            }
        }
        
        catch (ClassNotFoundException | SQLException e){
            label1.setText("Error de conexion" + e);
        }
    }
    
    private void limpiar(){
        txtIDT.setText(null);
        txtNombreT.setText(null);
        txtEdadT.setText(null);
        cbxGeneroT.setSelectedIndex(0);
        txtUsuarioT.setText(null);
        
        txtIDC.setText(null);
        txtNombreC.setText(null);
        txtEdadC.setText(null);
        cbxGeneroC.setSelectedIndex(0);
        txtCuentaC.setText(null);
        txtUsuarioC.setText(null);
        
        txtIDP.setText(null);
        txtNombreP.setText(null);
        txtDesarrolladoraP.setText(null);
        cbxGeneroP.setSelectedIndex(0);
        txtClasificacionP.setText(null);
        txtPrecioP.setText(null);
    }
    
    public ADMIN() {
        initComponents();
        
        this.setLocationRelativeTo(null);
        conector();
        
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jMenu17 = new javax.swing.JMenu();
        jMenu18 = new javax.swing.JMenu();
        jMenu19 = new javax.swing.JMenu();
        jMenu20 = new javax.swing.JMenu();
        jMenu21 = new javax.swing.JMenu();
        jMenu22 = new javax.swing.JMenu();
        jMenu23 = new javax.swing.JMenu();
        jMenu24 = new javax.swing.JMenu();
        jMenu25 = new javax.swing.JMenu();
        jMenu26 = new javax.swing.JMenu();
        jMenu27 = new javax.swing.JMenu();
        jMenu28 = new javax.swing.JMenu();
        jTextField11 = new javax.swing.JTextField();
        jTextField13 = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jTextField14 = new javax.swing.JTextField();
        jTextField15 = new javax.swing.JTextField();
        jTextField16 = new javax.swing.JTextField();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        infotab2 = new javax.swing.JTable();
        jScrollPane2 = new javax.swing.JScrollPane();
        infotab3 = new javax.swing.JTable();
        jScrollPane3 = new javax.swing.JScrollPane();
        infotab1 = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jSeparator2 = new javax.swing.JSeparator();
        btnSalir = new javax.swing.JButton();
        label1 = new javax.swing.JLabel();
        btnCargarT = new javax.swing.JButton();
        btnCargarC = new javax.swing.JButton();
        btnCargarP = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        txtEdadT = new javax.swing.JTextField();
        txtNombreT = new javax.swing.JTextField();
        txtIDT = new javax.swing.JTextField();
        jSeparator3 = new javax.swing.JSeparator();
        jSeparator4 = new javax.swing.JSeparator();
        AñadirT = new javax.swing.JButton();
        EliminarT = new javax.swing.JButton();
        ActualizarT = new javax.swing.JButton();
        ActualizarC = new javax.swing.JButton();
        AñadirC = new javax.swing.JButton();
        EliminarP = new javax.swing.JButton();
        ActualizarP = new javax.swing.JButton();
        AñadirP = new javax.swing.JButton();
        EliminarC = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        txtEdadC = new javax.swing.JTextField();
        txtNombreC = new javax.swing.JTextField();
        txtIDC = new javax.swing.JTextField();
        txtClasificacionP = new javax.swing.JTextField();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        txtDesarrolladoraP = new javax.swing.JTextField();
        txtNombreP = new javax.swing.JTextField();
        txtIDP = new javax.swing.JTextField();
        cbxGeneroC = new javax.swing.JComboBox<>();
        cbxGeneroP = new javax.swing.JComboBox<>();
        cbxGeneroT = new javax.swing.JComboBox<>();
        jLabel17 = new javax.swing.JLabel();
        txtUsuarioC = new javax.swing.JTextField();
        jLabel24 = new javax.swing.JLabel();
        txtPasswordC = new javax.swing.JPasswordField();
        jLabel25 = new javax.swing.JLabel();
        txtCuentaC = new javax.swing.JTextField();
        jLabel26 = new javax.swing.JLabel();
        txtUsuarioT = new javax.swing.JTextField();
        jLabel27 = new javax.swing.JLabel();
        txtPasswordT = new javax.swing.JPasswordField();
        txtPrecioP = new javax.swing.JTextField();
        jLabel28 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();

        jLabel9.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("ID:");

        jLabel10.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("Nombre:");

        jLabel11.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("Edad:");

        jLabel12.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setText("N.Ventas:");

        jLabel13.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(255, 255, 255));
        jLabel13.setText("Genero:");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(40, 11, 80));

        infotab2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "ID", "Nombre", "Edad", "Genero", "Usuario", "Password", "Cuenta"
            }
        ));
        infotab2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                infotab2MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(infotab2);

        infotab3.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "ID", "Nombre", "N.Desarrolladora", "Clasificacion", "Genero", "Precio"
            }
        ));
        infotab3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                infotab3MouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(infotab3);

        infotab1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "ID", "Nombre", "Edad", "Genero", "Usuario", "Password"
            }
        ));
        infotab1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                infotab1MouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(infotab1);

        jLabel1.setFont(new java.awt.Font("Verdana", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("TRABAJADOR");

        jLabel2.setFont(new java.awt.Font("Verdana", 1, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("CLIENTE");

        jLabel3.setFont(new java.awt.Font("Verdana", 1, 24)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("PRODUCTO");

        btnSalir.setText("SALIR");
        btnSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalirActionPerformed(evt);
            }
        });

        label1.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        label1.setForeground(new java.awt.Color(255, 255, 255));

        btnCargarT.setText("Cargar");
        btnCargarT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCargarTActionPerformed(evt);
            }
        });

        btnCargarC.setText("Cargar");
        btnCargarC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCargarCActionPerformed(evt);
            }
        });

        btnCargarP.setText("Cargar");
        btnCargarP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCargarPActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jSeparator2)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(btnSalir)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(label1, javax.swing.GroupLayout.PREFERRED_SIZE, 222, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnCargarT))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jSeparator1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnCargarC)))
                .addContainerGap())
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 626, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(35, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 626, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(34, 34, 34))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addGap(286, 286, 286))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(250, 250, 250))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 626, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(29, 29, 29))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addGap(177, 177, 177)
                        .addComponent(btnCargarP)
                        .addContainerGap())))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnSalir)
                    .addComponent(label1, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnCargarT))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 11, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel2)
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(btnCargarC))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel3)
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 177, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(btnCargarP))
                .addGap(16, 16, 16))
        );

        jPanel2.setBackground(new java.awt.Color(50, 17, 94));

        AñadirT.setText("AÑADIR");
        AñadirT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AñadirTActionPerformed(evt);
            }
        });

        EliminarT.setText("ELIMINAR");
        EliminarT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EliminarTActionPerformed(evt);
            }
        });

        ActualizarT.setText("EDITAR");
        ActualizarT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ActualizarTActionPerformed(evt);
            }
        });

        ActualizarC.setText("ACTUALIZAR");
        ActualizarC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ActualizarCActionPerformed(evt);
            }
        });

        AñadirC.setText("AÑADIR");
        AñadirC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AñadirCActionPerformed(evt);
            }
        });

        EliminarP.setText("ELIMINAR");
        EliminarP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EliminarPActionPerformed(evt);
            }
        });

        ActualizarP.setText("ACTUALIZAR");
        ActualizarP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ActualizarPActionPerformed(evt);
            }
        });

        AñadirP.setText("AÑADIR");
        AñadirP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AñadirPActionPerformed(evt);
            }
        });

        EliminarC.setText("ELIMINAR");
        EliminarC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EliminarCActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("ID:");

        jLabel5.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Nombre:");

        jLabel6.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Edad:");

        jLabel8.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Genero:");

        jLabel14.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(255, 255, 255));
        jLabel14.setText("ID:");

        jLabel15.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(255, 255, 255));
        jLabel15.setText("Nombre:");

        jLabel16.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(255, 255, 255));
        jLabel16.setText("Edad:");

        jLabel18.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(255, 255, 255));
        jLabel18.setText("Genero:");

        jLabel19.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        jLabel19.setForeground(new java.awt.Color(255, 255, 255));
        jLabel19.setText("ID:");

        jLabel20.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(255, 255, 255));
        jLabel20.setText("Nombre:");

        jLabel21.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        jLabel21.setForeground(new java.awt.Color(255, 255, 255));
        jLabel21.setText("Desarrolladora:");

        jLabel22.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        jLabel22.setForeground(new java.awt.Color(255, 255, 255));
        jLabel22.setText("Clasificacion:");

        jLabel23.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        jLabel23.setForeground(new java.awt.Color(255, 255, 255));
        jLabel23.setText("Genero:");

        cbxGeneroC.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "SELECCIONAR", "MASCULINO", "FEMENINO" }));

        cbxGeneroP.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "SELECCIONAR", "ACCION", "TERROR", "DEPORTE", "AVENTURA" }));

        cbxGeneroT.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "SELECCIONAR", "MASCULINO", "FEMENINO" }));

        jLabel17.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(255, 255, 255));
        jLabel17.setText("Usuario:");

        jLabel24.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        jLabel24.setForeground(new java.awt.Color(255, 255, 255));
        jLabel24.setText("Password:");

        jLabel25.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        jLabel25.setForeground(new java.awt.Color(255, 255, 255));
        jLabel25.setText("Cuenta:");

        jLabel26.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        jLabel26.setForeground(new java.awt.Color(255, 255, 255));
        jLabel26.setText("Usuario:");

        jLabel27.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        jLabel27.setForeground(new java.awt.Color(255, 255, 255));
        jLabel27.setText("Password:");

        jLabel28.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        jLabel28.setForeground(new java.awt.Color(255, 255, 255));
        jLabel28.setText("Precio:");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jSeparator3)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(AñadirC)
                                .addGap(68, 68, 68)
                                .addComponent(EliminarC))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(AñadirP)
                                .addGap(80, 80, 80)
                                .addComponent(EliminarP)
                                .addGap(53, 53, 53)
                                .addComponent(ActualizarP)))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jSeparator4, javax.swing.GroupLayout.DEFAULT_SIZE, 444, Short.MAX_VALUE)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(36, 36, 36)
                                .addComponent(jLabel4)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(txtIDT, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jLabel5)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(txtNombreT, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addGap(36, 36, 36)
                                        .addComponent(jLabel14))
                                    .addComponent(jLabel16, javax.swing.GroupLayout.Alignment.TRAILING))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addComponent(txtEdadC, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(32, 32, 32)
                                        .addComponent(jLabel18))
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addComponent(txtIDC, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(jPanel2Layout.createSequentialGroup()
                                                .addGap(156, 156, 156)
                                                .addComponent(ActualizarC))
                                            .addGroup(jPanel2Layout.createSequentialGroup()
                                                .addGap(18, 18, 18)
                                                .addComponent(jLabel15)
                                                .addGap(18, 18, 18)
                                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(cbxGeneroC, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(txtNombreC, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)))))))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(9, 9, 9)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addGroup(jPanel2Layout.createSequentialGroup()
                                            .addComponent(jLabel24)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                            .addComponent(txtPasswordC))
                                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel2Layout.createSequentialGroup()
                                            .addComponent(jLabel17)
                                            .addGap(24, 24, 24)
                                            .addComponent(txtUsuarioC, javax.swing.GroupLayout.PREFERRED_SIZE, 187, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addComponent(jLabel25)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(txtCuentaC, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE))))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(9, 9, 9)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(jPanel2Layout.createSequentialGroup()
                                                .addComponent(jLabel19)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(txtIDP, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addComponent(jLabel21))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(jPanel2Layout.createSequentialGroup()
                                                .addComponent(jLabel20)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(txtNombreP, javax.swing.GroupLayout.PREFERRED_SIZE, 186, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(jPanel2Layout.createSequentialGroup()
                                                .addComponent(txtDesarrolladoraP, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(jLabel22)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(txtClasificacionP, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addComponent(jLabel28)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(txtPrecioP, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(jLabel23)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(cbxGeneroP, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                        .addContainerGap())))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel2Layout.createSequentialGroup()
                            .addGap(31, 31, 31)
                            .addComponent(jLabel6)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(txtEdadT, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                    .addComponent(jLabel8)
                                    .addGap(177, 177, 177))
                                .addGroup(jPanel2Layout.createSequentialGroup()
                                    .addGap(66, 66, 66)
                                    .addComponent(cbxGeneroT, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGroup(jPanel2Layout.createSequentialGroup()
                            .addGap(14, 14, 14)
                            .addComponent(jLabel26)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(txtUsuarioT, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(jLabel27)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(txtPasswordT, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(44, 44, 44)
                        .addComponent(AñadirT)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(EliminarT)
                        .addGap(55, 55, 55)
                        .addComponent(ActualizarT)
                        .addGap(26, 26, 26)))
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtIDT, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4)
                    .addComponent(txtNombreT, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(txtEdadT, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel6))
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(cbxGeneroT, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel8)))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel27)
                        .addComponent(txtPasswordT, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(txtUsuarioT, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel26))
                .addGap(28, 28, 28)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(AñadirT)
                    .addComponent(EliminarT)
                    .addComponent(ActualizarT))
                .addGap(59, 59, 59)
                .addComponent(jSeparator4, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtIDC, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel14)
                    .addComponent(txtNombreC, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel15))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtEdadC, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel16)
                    .addComponent(jLabel18)
                    .addComponent(cbxGeneroC, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(17, 17, 17)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel25)
                    .addComponent(txtCuentaC, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtUsuarioC, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel17))
                .addGap(16, 16, 16)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel24)
                    .addComponent(txtPasswordC, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(21, 21, 21)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(AñadirC)
                    .addComponent(EliminarC)
                    .addComponent(ActualizarC))
                .addGap(24, 24, 24)
                .addComponent(jSeparator3, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtIDP, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel19)
                    .addComponent(jLabel20)
                    .addComponent(txtNombreP, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel21)
                    .addComponent(txtDesarrolladoraP, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel22)
                    .addComponent(txtClasificacionP, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel23)
                        .addComponent(cbxGeneroP, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(txtPrecioP, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel28)))
                .addGap(71, 71, 71)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(AñadirP)
                    .addComponent(EliminarP)
                    .addComponent(ActualizarP))
                .addContainerGap(27, Short.MAX_VALUE))
        );

        jMenuBar1.setBackground(new java.awt.Color(255, 255, 255));
        jMenuBar1.setForeground(new java.awt.Color(51, 0, 153));
        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalirActionPerformed
        Login form=new Login();
        form.setVisible(true);
        this.dispose();
        
        try{
            DefaultTableModel modelo= new DefaultTableModel();
            infotab1.setModel(modelo);
            
            PreparedStatement ps= null;
            ResultSet rs= null;
            Conexion conn= new Conexion();
            Connection con=conn.getConexion();
            
            String sql="SELECT * FROM trabajador";
            ps=con.prepareStatement(sql);
            rs=ps.executeQuery();
            
            ResultSetMetaData rsMD=rs.getMetaData();
            int cantidadColumnas=rsMD.getColumnCount();
            
            modelo.addColumn("ID");
            modelo.addColumn("Nombre");
            modelo.addColumn("Edad");
            modelo.addColumn("Genero");
            modelo.addColumn("Usuario");
            modelo.addColumn("Password");
            
            while(rs.next()){
                Object[] filas=new Object[cantidadColumnas];
                
                for(int i=0; i< cantidadColumnas; i++)
                {
                    filas[i]=rs.getObject(i + 1 );
                }
                modelo.addRow(filas);
            }
        
        } catch(SQLException ex) {
            System.err.println(ex.toString());
        }
    }//GEN-LAST:event_btnSalirActionPerformed

    private void AñadirTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AñadirTActionPerformed
        String pass=String.valueOf(txtPasswordT.getPassword());
            String SQL="INSERT INTO trabajador (ID, Nombre, Edad, Genero, Usuario, Password) VALUES (?,?,?,?,?,?)";
        
        try {
            PreparedStatement pat=conectar.prepareStatement(SQL);
            pat.setString(1,txtIDT.getText());
            pat.setString(2,txtNombreT.getText());
            pat.setString(3,txtEdadT.getText());
            pat.setString(4,cbxGeneroT.getSelectedItem().toString());
            pat.setString(5,txtUsuarioT.getText());
            pat.setString(6,pass);
                    
            pat.executeUpdate();
            JOptionPane.showMessageDialog(null,"Registro Completo");
            limpiar();
        }catch (Exception e){
            JOptionPane.showMessageDialog(null,"Registro Denegado " + e.getMessage());
        }
    }//GEN-LAST:event_AñadirTActionPerformed

    private void AñadirCActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AñadirCActionPerformed
        String pass=String.valueOf(txtPasswordC.getPassword());
            String SQL="INSERT INTO cliente (ID, Nombre, Edad, Genero, Cuenta, Usuario, Password) VALUES (?,?,?,?,?,?,?)";
        
        try {
            PreparedStatement pat=conectar.prepareStatement(SQL);
            pat.setString(1,txtIDC.getText());
            pat.setString(2,txtNombreC.getText());
            pat.setString(3,txtEdadC.getText());
            pat.setString(4,cbxGeneroC.getSelectedItem().toString());
            pat.setString(5,txtCuentaC.getText());
            pat.setString(6,txtUsuarioC.getText());
            pat.setString(7,pass);
                    
            pat.executeUpdate();
            JOptionPane.showMessageDialog(null,"Registro Completo");
            limpiar();
        }catch (Exception e){
            JOptionPane.showMessageDialog(null,"Registro Denegado " + e.getMessage());
        }
    }//GEN-LAST:event_AñadirCActionPerformed

    private void AñadirPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AñadirPActionPerformed
        String SQL="INSERT INTO producto (ID, Nombre, NDesarrolladora, Clasificacion, Genero, Precio) VALUES (?,?,?,?,?,?)";
        
        try {
            PreparedStatement pat=conectar.prepareStatement(SQL);
            pat.setString(1,txtIDP.getText());
            pat.setString(2,txtNombreP.getText());
            pat.setString(3,txtDesarrolladoraP.getText());
            pat.setString(4,txtClasificacionP.getText());
            pat.setString(5,cbxGeneroP.getSelectedItem().toString());
            pat.setString(6,txtPrecioP.getText());
            
                    
            pat.executeUpdate();
            JOptionPane.showMessageDialog(null,"Registro Completo");
            limpiar();
        }catch (Exception e){
            JOptionPane.showMessageDialog(null,"Registro Denegado " + e.getMessage());
        }
    }//GEN-LAST:event_AñadirPActionPerformed

    private void EliminarTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EliminarTActionPerformed
        PreparedStatement ps= null;
        try {
            Conexion objCon =new Conexion();
            Connection conn = objCon.getConexion();
            
            int Fila = infotab1.getSelectedRow();
            String codigo = infotab1.getValueAt(Fila,0).toString();
            
            ps = conn.prepareStatement("DELETE FROM trabajador WHERE ID=?");
            ps.setString(1, codigo);
            ps.execute();
            
            modelo.removeRow(Fila);
            
        }catch (Exception ex){
            System.out.println(ex.toString());
        }
    }//GEN-LAST:event_EliminarTActionPerformed

    private void EliminarCActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EliminarCActionPerformed
        PreparedStatement ps= null;
        try {
            Conexion objCon =new Conexion();
            Connection conn = objCon.getConexion();
            
            int Fila = infotab2.getSelectedRow();
            String codigo = infotab2.getValueAt(Fila,0).toString();
            
            ps = conn.prepareStatement("DELETE FROM cliente WHERE ID=?");
            ps.setString(1, codigo);
            ps.execute();
            
            modelos.removeRow(Fila);
            
        }catch (Exception ex){
            System.out.println(ex.toString());
        }
    }//GEN-LAST:event_EliminarCActionPerformed

    private void EliminarPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EliminarPActionPerformed
        PreparedStatement ps= null;
        try {
            Conexion objCon =new Conexion();
            Connection conn = objCon.getConexion();
            
            int Fila = infotab3.getSelectedRow();
            String codigo = infotab3.getValueAt(Fila,0).toString();
            
            ps = conn.prepareStatement("DELETE FROM producto WHERE ID=?");
            ps.setString(1, codigo);
            ps.execute();
            
            model.removeRow(Fila);
            
        }catch (Exception ex){
            System.out.println(ex.toString());
        }
    }//GEN-LAST:event_EliminarPActionPerformed

    private void btnCargarTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCargarTActionPerformed
        try{
            DefaultTableModel modelo= new DefaultTableModel();
            infotab1.setModel(modelo);
            
            PreparedStatement ps= null;
            ResultSet rs= null;
            Conexion conn= new Conexion();
            Connection con=conn.getConexion();
            
            String sql="SELECT * FROM trabajador";
            ps=con.prepareStatement(sql);
            rs=ps.executeQuery();
            
            ResultSetMetaData rsMD=rs.getMetaData();
            int cantidadColumnas=rsMD.getColumnCount();
            
            modelo.addColumn("ID");
            modelo.addColumn("Nombre");
            modelo.addColumn("Edad");
            modelo.addColumn("Genero");
            modelo.addColumn("Usuario");
            modelo.addColumn("Password");
            
            while(rs.next()){
                Object[] filas=new Object[cantidadColumnas];
                
                for(int i=0; i< cantidadColumnas; i++)
                {
                    filas[i]=rs.getObject(i + 1 );
                }
                modelo.addRow(filas);
            }
        
        } catch(SQLException ex) {
            System.err.println(ex.toString());
        }
    }//GEN-LAST:event_btnCargarTActionPerformed

    private void btnCargarCActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCargarCActionPerformed
        try{
            DefaultTableModel modelos= new DefaultTableModel();
            infotab2.setModel(modelos);
            
            PreparedStatement ps= null;
            ResultSet rs= null;
            Conexion conn= new Conexion();
            Connection con=conn.getConexion();
            
            String sql="SELECT * FROM cliente";
            ps=con.prepareStatement(sql);
            rs=ps.executeQuery();
            
            ResultSetMetaData rsMD=rs.getMetaData();
            int cantidadColumnas=rsMD.getColumnCount();
            
            modelos.addColumn("ID");
            modelos.addColumn("Nombre");
            modelos.addColumn("Edad");
            modelos.addColumn("Genero");
            modelos.addColumn("Cuenta");
            modelos.addColumn("Usuario");
            modelos.addColumn("Password");
            
            while(rs.next()){
                Object[] filas=new Object[cantidadColumnas];
                
                for(int i=0; i< cantidadColumnas; i++)
                {
                    filas[i]=rs.getObject(i + 1 );
                }
                modelos.addRow(filas);
            }
        
        } catch(SQLException ex) {
            System.err.println(ex.toString());
        }
    }//GEN-LAST:event_btnCargarCActionPerformed

    private void btnCargarPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCargarPActionPerformed
        try{
            DefaultTableModel model= new DefaultTableModel();
            infotab3.setModel(model);
            
            PreparedStatement ps= null;
            ResultSet rs= null;
            Conexion conn= new Conexion();
            Connection con=conn.getConexion();
            
            String sql="SELECT * FROM producto";
            ps=con.prepareStatement(sql);
            rs=ps.executeQuery();
            
            ResultSetMetaData rsMD=rs.getMetaData();
            int cantidadColumnas=rsMD.getColumnCount();
            
            model.addColumn("ID");
            model.addColumn("Nombre");
            model.addColumn("Desarrolladora");
            model.addColumn("Clasificacion");
            model.addColumn("Genero");
            model.addColumn("Precio");
            
            while(rs.next()){
                Object[] filas=new Object[cantidadColumnas];
                
                for(int i=0; i< cantidadColumnas; i++)
                {
                    filas[i]=rs.getObject(i + 1 );
                }
                model.addRow(filas);
            }
        
        } catch(SQLException ex) {
            System.err.println(ex.toString());
        }
    }//GEN-LAST:event_btnCargarPActionPerformed

    private void infotab1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_infotab1MouseClicked
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            Conexion objCon = new Conexion();
            Connection conn = objCon.getConexion();

            int Fila = infotab1.getSelectedRow();
            String codigo = infotab1.getValueAt(Fila, 0).toString();

            ps = conn.prepareStatement("SELECT ID, Nombre, Edad, Genero, Usuario, Password FROM trabajador WHERE ID=?");
            ps.setString(1, codigo);
            rs = ps.executeQuery();

            while (rs.next()) {
                txtIDT.setText(rs.getString("ID"));
                txtNombreT.setText(rs.getString("Nombre"));
                txtEdadT.setText(rs.getString("Edad"));
                cbxGeneroT.setSelectedItem(rs.getString("Genero"));
                txtUsuarioT.setText(rs.getString("Usuario"));
                txtPasswordT.setText(rs.getString("Password"));
            }
        } catch (SQLException ex) {
            System.out.println(ex.toString());
        }
    }//GEN-LAST:event_infotab1MouseClicked

    private void ActualizarTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ActualizarTActionPerformed
        String pass=String.valueOf(txtPasswordT.getPassword());
        int Fila = infotab1.getSelectedRow();

        PreparedStatement ps = null;
        try {
            Conexion objCon = new Conexion();
            Connection conn = objCon.getConexion();
            ps = conn.prepareStatement("UPDATE trabajador SET Nombre=?, Edad=?, Genero=?, Usuario=?, Password=? WHERE ID=?");

            ps.setString(1, txtIDT.getText());
            ps.setString(2, txtNombreT.getText());
            ps.setString(3, txtEdadT.getText());
            ps.setString(4, cbxGeneroC.getSelectedItem().toString());
            ps.setString(5, txtUsuarioT.getText());
            ps.setString(6, pass);

            ps.execute();

            JOptionPane.showMessageDialog(null, "Trabajador Modificado");
            infotab1.setValueAt(txtIDT.getText(), Fila, 0);
            infotab1.setValueAt(txtNombreT.getText(), Fila, 1);
            infotab1.setValueAt(txtEdadT.getText(), Fila, 2);
            infotab1.setValueAt(cbxGeneroC.getSelectedItem().toString(), Fila, 3);
            infotab1.setValueAt(txtUsuarioT.getText(), Fila, 4);
            infotab1.setValueAt(pass, Fila, 5);

            limpiar();

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al Modificar Trabajador");
            System.out.println(ex);
        }
    }//GEN-LAST:event_ActualizarTActionPerformed

    private void infotab2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_infotab2MouseClicked
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            Conexion objCon = new Conexion();
            Connection conn = objCon.getConexion();

            int Fila = infotab2.getSelectedRow();
            String codigo = infotab2.getValueAt(Fila, 0).toString();

            ps = conn.prepareStatement("SELECT ID, Nombre, Edad, Genero, Cuenta, Usuario, Password FROM cliente WHERE ID=?");
            ps.setString(1, codigo);
            rs = ps.executeQuery();

            while (rs.next()) {
                txtIDC.setText(rs.getString("ID"));
                txtNombreC.setText(rs.getString("Nombre"));
                txtEdadC.setText(rs.getString("Edad"));
                cbxGeneroC.setSelectedItem(rs.getString("Genero"));
                txtCuentaC.setText(rs.getString("Cuenta"));
                txtUsuarioC.setText(rs.getString("Usuario"));
                txtPasswordC.setText(rs.getString("Password"));
            }
        } catch (SQLException ex) {
            System.out.println(ex.toString());
        }
    }//GEN-LAST:event_infotab2MouseClicked

    private void ActualizarCActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ActualizarCActionPerformed
        String pass=String.valueOf(txtPasswordC.getPassword());
        int Fila = infotab2.getSelectedRow();

        PreparedStatement ps = null;
        try {
            Conexion objCon = new Conexion();
            Connection conn = objCon.getConexion();
            ps = conn.prepareStatement("UPDATE cliente SET Nombre=?, Edad=?, Genero=?, Cuenta=?, Usuario=?, Password=? WHERE ID=?");

            ps.setString(1, txtIDC.getText());
            ps.setString(2, txtNombreC.getText());
            ps.setString(3, txtEdadC.getText());
            ps.setString(4, cbxGeneroC.getSelectedItem().toString());
            ps.setString(5, txtCuentaC.getText());
            ps.setString(6, txtUsuarioC.getText());
            ps.setString(7, pass);

            ps.execute();

            JOptionPane.showMessageDialog(null, "Ciente Modificado");
            infotab2.setValueAt(txtIDC.getText(), Fila, 0);
            infotab2.setValueAt(txtNombreC.getText(), Fila, 1);
            infotab2.setValueAt(txtEdadC.getText(), Fila, 2);
            infotab2.setValueAt(cbxGeneroC.getSelectedItem().toString(), Fila, 3);
            infotab2.setValueAt(txtCuentaC.getText(), Fila, 4);
            infotab2.setValueAt(txtUsuarioC.getText(), Fila, 5);
            infotab2.setValueAt(pass, Fila, 6);

            limpiar();

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al Modificar Cliente");
            System.out.println(ex);
        }
    }//GEN-LAST:event_ActualizarCActionPerformed

    private void infotab3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_infotab3MouseClicked
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            Conexion objCon = new Conexion();
            Connection conn = objCon.getConexion();

            int Fila = infotab3.getSelectedRow();
            String codigo = infotab3.getValueAt(Fila, 0).toString();

            ps = conn.prepareStatement("SELECT ID, Nombre, NDesarrolladora, Clasificacion, Genero, Precio FROM producto WHERE ID=?");
            ps.setString(1, codigo);
            rs = ps.executeQuery();

            while (rs.next()) {
                txtIDP.setText(rs.getString("ID"));
                txtNombreP.setText(rs.getString("Nombre"));
                txtDesarrolladoraP.setText(rs.getString("NDesarrolladora"));
                txtClasificacionP.setText(rs.getString("Clasificacion"));
                cbxGeneroP.setSelectedItem(rs.getString("Genero"));
                txtPrecioP.setText(rs.getString("Precio"));
                
            }
        } catch (SQLException ex) {
            System.out.println(ex.toString());
        }
    }//GEN-LAST:event_infotab3MouseClicked

    private void ActualizarPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ActualizarPActionPerformed
        
        int Filas = infotab3.getSelectedRow();

        PreparedStatement ps = null;
        try {
            Conexion objCon = new Conexion();
            Connection conn = objCon.getConexion();
            ps = conn.prepareStatement("UPDATE producto SET Nombre=?, NDesarrolladora=?, Clasificacion=?, Genero=?, Precio=? WHERE ID=?");

            ps.setString(1, txtIDP.getText());
            ps.setString(2, txtNombreP.getText());
            ps.setString(3, txtDesarrolladoraP.getText());
            ps.setString(4, txtClasificacionP.getText());
            ps.setString(5, cbxGeneroP.getSelectedItem().toString());
            ps.setString(6, txtPrecioP.getText());
            

            ps.execute();

            JOptionPane.showMessageDialog(null, "Producto Modificado");
            infotab3.setValueAt(txtIDP.getText(), Filas, 0);
            infotab3.setValueAt(txtNombreP.getText(), Filas, 1);
            infotab3.setValueAt(txtDesarrolladoraP.getText(), Filas, 2);
            infotab3.setValueAt(txtClasificacionP.getText(), Filas, 3);
            infotab3.setValueAt(cbxGeneroP.getSelectedItem().toString(), Filas, 4);
            infotab3.setValueAt(txtPrecioP.getText(), Filas, 5);
            

            limpiar();

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al Modificar Producto");
            System.out.println(ex);
        }
    }//GEN-LAST:event_ActualizarPActionPerformed

    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ADMIN.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ADMIN.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ADMIN.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ADMIN.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ADMIN().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton ActualizarC;
    private javax.swing.JButton ActualizarP;
    private javax.swing.JButton ActualizarT;
    private javax.swing.JButton AñadirC;
    private javax.swing.JButton AñadirP;
    private javax.swing.JButton AñadirT;
    private javax.swing.JButton EliminarC;
    private javax.swing.JButton EliminarP;
    private javax.swing.JButton EliminarT;
    private javax.swing.JButton btnCargarC;
    private javax.swing.JButton btnCargarP;
    private javax.swing.JButton btnCargarT;
    private javax.swing.JButton btnSalir;
    private javax.swing.JComboBox<String> cbxGeneroC;
    private javax.swing.JComboBox<String> cbxGeneroP;
    private javax.swing.JComboBox<String> cbxGeneroT;
    private javax.swing.JTable infotab1;
    private javax.swing.JTable infotab2;
    private javax.swing.JTable infotab3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JMenu jMenu17;
    private javax.swing.JMenu jMenu18;
    private javax.swing.JMenu jMenu19;
    private javax.swing.JMenu jMenu20;
    private javax.swing.JMenu jMenu21;
    private javax.swing.JMenu jMenu22;
    private javax.swing.JMenu jMenu23;
    private javax.swing.JMenu jMenu24;
    private javax.swing.JMenu jMenu25;
    private javax.swing.JMenu jMenu26;
    private javax.swing.JMenu jMenu27;
    private javax.swing.JMenu jMenu28;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JTextField jTextField11;
    private javax.swing.JTextField jTextField13;
    private javax.swing.JTextField jTextField14;
    private javax.swing.JTextField jTextField15;
    private javax.swing.JTextField jTextField16;
    private javax.swing.JLabel label1;
    private javax.swing.JTextField txtClasificacionP;
    private javax.swing.JTextField txtCuentaC;
    private javax.swing.JTextField txtDesarrolladoraP;
    private javax.swing.JTextField txtEdadC;
    private javax.swing.JTextField txtEdadT;
    private javax.swing.JTextField txtIDC;
    private javax.swing.JTextField txtIDP;
    private javax.swing.JTextField txtIDT;
    private javax.swing.JTextField txtNombreC;
    private javax.swing.JTextField txtNombreP;
    private javax.swing.JTextField txtNombreT;
    private javax.swing.JPasswordField txtPasswordC;
    private javax.swing.JPasswordField txtPasswordT;
    private javax.swing.JTextField txtPrecioP;
    private javax.swing.JTextField txtUsuarioC;
    private javax.swing.JTextField txtUsuarioT;
    // End of variables declaration//GEN-END:variables
}
