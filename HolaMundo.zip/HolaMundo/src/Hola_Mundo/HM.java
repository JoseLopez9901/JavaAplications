package Hola_Mundo;
import java.awt.*;
import java.awt.event.ActionListener;
import java.io.Console;
import java.util.*;
import java.util.Timer;
import java.util.TimerTask;
import static java.util.concurrent.TimeUnit.HOURS;
import static java.util.concurrent.TimeUnit.SECONDS;
import java.util.concurrent.*;
import java.util.Scanner;
import java.util.StringTokenizer;

public class HM {
    public static void main(String[] args) throws InterruptedException {
        Scanner opciones = new Scanner(System.in);
        int opcion;
            System.out.println("¡¡BIENVENIDO!!, Selecciona que acción deseas realizar ");
            System.out.println("1. Suma de 2 números");
            System.out.println("2. Multiplicación de 2 números");
            System.out.println("3. División de 2 números");
            System.out.println("4. Timer");
            System.out.println("5. Cronómetro");
            System.out.println("6. Contador de letras");
            System.out.println("7. Actividades anteriores");
            System.out.println("8. Salir");
            System.out.print("->");
            opcion= opciones.nextInt();

                switch (opcion){
                    case 1:
                        OperacionesBasicas.Suma(args);
                        RepetirAccion.RepeatSuma(args);
                        break;
                    case 2:
                        OperacionesBasicas.Multiplicación(args);
                        RepetirAccion.RepeatMulti(args);
                        break;
                    case 3:
                        OperacionesBasicas.División(args);
                        RepetirAccion.RepeatDiv(args);
                        break;
                    case 4:
                        Acciones.Timer(args);
                        RepetirAccion.RepeatTimer(args);
                        break;
                    case 5:
                        Acciones.Cronometro(args);
                        RepetirAccion.RepeatCrono(args);

                        break;
                    case 6:
                        Acciones.ContadorLetras(args);
                        RepetirAccion.RepeatContador(args);
                        resultados.resultContP(String.valueOf(args));
                        break;
                    case 7:
                        Acciones.ActividadAnterior(args);
                        RepetirAccion.RepeatActividadA(args);
                        break;
                    case 8:
                        System.out.println("No vemos pronto!!");
                        System.exit(0);
                        break;
                    default:
                        System.out.println("¡Opcion invalida!");
                        main(args);
                }
    }
    //*Clases*//
    public static class OperacionesBasicas{
        public static void Suma (String[] args){
            Scanner leer = new Scanner(System.in);
            double Pvalor = 0, Svalor=0, resultado=0;

            System.out.println("/////SUMA/////");
            System.out.println("Ingresa los correspondientes valores...");
            System.out.print("Primer Valor: ");
            Pvalor = leer.nextDouble();
            System.out.print("Segundo Valor: ");
            Svalor =leer.nextDouble();
                resultados.resultSum(Pvalor,Svalor,resultado);
        }
        public static void Multiplicación (String[] args){
            Scanner leer1 = new Scanner(System.in);
            double Pvalor = 0, Svalor=0, resultado=0;

            System.out.println("/////MULTIPLICACIÓN/////");
            System.out.println("Ingresa los correspondientes valores...");
            System.out.print("Primer Valor: ");
            Pvalor = leer1.nextDouble();
            System.out.print("Segundo Valor: ");
            Svalor =leer1.nextDouble();
                resultados.resultMulti(Pvalor,Svalor,resultado);
        }
        public static void División (String[] args){
            Scanner leer2 = new Scanner(System.in);
            double Pvalor = 0, Svalor=0, resultado=0;

            System.out.println("/////DIVISIÓN/////");
            System.out.println("Ingresa los correspondientes valores...");
            System.out.print("Primer Valor: ");
            Pvalor = leer2.nextDouble();
            System.out.print("Segundo Valor: ");
            Svalor = leer2.nextDouble();
                resultados.resultDiv(Pvalor,Svalor,resultado);
        }
    }
    public class resultados {
        public static int resultSum(double Pvalor, double Svalor, double resultado) {
            resultado = Pvalor + Svalor;
            System.out.println("La suma de " + Pvalor + " + " + Svalor + " es " + resultado);
            return (int) resultado;
        }
        public static int resultMulti(double Pvalor, double Svalor, double resultado) {
            resultado = Pvalor * Svalor;
            System.out.println("La multiplicación de " + Pvalor + " * " + Svalor + " es " + resultado);
            return (int) resultado;
        }
        public static int resultDiv(double Pvalor, double Svalor, double resultado) {
            resultado = Pvalor / Svalor;
            System.out.println("La división de " + Pvalor + " / " + Svalor + " es " + resultado);
            return (int) resultado;
        }
        public static int resultTimer (String [] args) throws InterruptedException {
            Scanner t = new Scanner(System.in);
            int numero;
            System.out.print("Ingresa el tiempo: ");
            numero=t.nextInt();

            for (numero = numero; numero>=0; numero--) {
                try {
                    Thread.sleep (1000);
                }
                catch (InterruptedException e) {
                    e.printStackTrace();
                }
                System.out.println(numero);
            }
            return numero;
        }
        public static int resultContP (String s) {
            int contador = 1, pos;
            s = s.trim();
            if (s.isEmpty()) {
                contador = 0;
            } else {
                pos = s.indexOf(" ");
                while (pos != -1) {
                    contador++;
                    pos = s.indexOf(" ", pos + 1);
                }
            }
            System.out.println("El numero de letras de la frase ingresada: " +contador);
            return contador;
        }
    }
    public class Acciones {

        public static void Timer (String[] args) throws InterruptedException {
            Scanner opcioness = new Scanner(System.in);
            int opcions;

            System.out.println("/////TIMER/////");
            System.out.println("¿Desea iniciar el timer?");
            System.out.println("1. Si");
            System.out.println("2. No");

            opcions = opcioness.nextInt();
            switch (opcions) {
                case 1:
                    resultados.resultTimer(args);
                    break;
                case 2:
                    System.out.println("Accion finalizada");
                    main(args);
                    break;
            }
        }
        public static void Cronometro (String[] args) throws InterruptedException {
            Scanner opciones = new Scanner(System.in);
            int opcion;
            System.out.println("/////CRONOMETRO/////");
            System.out.println("¿Desea iniciar el cronometro?");
            System.out.println("1. Si");
            System.out.println("2. No");

            opcion= opciones.nextInt();
            switch (opcion){
                case 1:
                    long t1, t2, dif;
                    String cad;
                    Scanner teclado = new Scanner(System.in);

                    Calendar ahora1 = Calendar.getInstance();
                    t1 = ahora1.getTimeInMillis();

                    System.out.println("Empieza a contar el tiempo.");
                    System.out.print("Pulsa Intro para finalizar \n");
                    cad = teclado.nextLine();

                    Calendar ahora2 = Calendar.getInstance();
                    t2 = ahora2.getTimeInMillis();

                    dif = t2 - t1;

                    System.out.printf("Has tardado: %.3f segundos \n", (double) dif / 1000 );
                break;
                case 2:
                    System.out.println("Ta wueno!!");
                    main(args);
                    break;
            }
        }
        public static void ContadorLetras(String[] args){
            Scanner texto = new Scanner(System.in);
            String abc;
            System.out.print("Igrese el texto: ");
            abc=texto.nextLine();

            long letrass=abc.chars().filter(ch -> ch != ' ').count();
            System.out.println("El total de letras en tl texto son: "+ letrass +" palabras");
        }
        public static void ActividadAnterior (String[] args){
            Scanner var = new Scanner(System.in);
            int parametro1 = 0, parametro2 = 0;
            System.out.println("Hola Mundo!! Los valores ingresados se veran reflejados en la consola");
            System.out.println("Ingresa primer valor: ");
            parametro1= var.nextInt();
            System.out.println("Ingresa Segundo valor: ");
            parametro2 = var.nextInt();

            System.out.println("Los valores ingresados son");
            System.out.println("Valor 1: " + parametro1);
            System.out.println("Valor 2: " + parametro2);
        }
    }
    public static class RepetirAccion{
        public static void RepeatSuma(String[] args) throws InterruptedException {
            Scanner opciones = new Scanner(System.in);
            int opcion;
            do {
                System.out.println("\n¿Desea repetir actividad?");
                System.out.println("1. Si");
                System.out.println("2. No");
                System.out.println("3. Salir");
                opcion= opciones.nextInt();

                switch (opcion){
                    case 1:
                        OperacionesBasicas.Suma(args);
                        break;
                    case 2:
                        main(args);
                        break;
                    case 3:
                        System.out.println("Acción finalizada");
                        System.exit(0);
                        break;
                    default:
                        System.out.println("Ingresa una opcion valida");
                        RepetirAccion.RepeatSuma(args);
                }
            }while (opcion!=3);
                System.out.println("¡Opcion invalida!");
        }
        public static void RepeatMulti(String[] args) throws InterruptedException {
            Scanner opciones = new Scanner(System.in);
            int opcion;
            do {
                System.out.println("\n¿Desea repetir actividad?");
                System.out.println("1. Si");
                System.out.println("2. No");
                System.out.println("3. Salir");
                opcion= opciones.nextInt();

                switch (opcion){
                    case 1:
                        OperacionesBasicas.Multiplicación(args);
                        break;
                    case 2:
                        main(args);
                        break;
                    case 3:
                        System.out.println("Acción finalizada");
                        System.exit(0);
                        break;
                    default:
                        System.out.println("Ingresa una opcion valida");
                        RepetirAccion.RepeatMulti(args);
                }
            }while (opcion!=3);
            System.out.println("¡Opcion invalida!");
        }
        public static void RepeatDiv(String[] args) throws InterruptedException {
            Scanner opciones = new Scanner(System.in);
            int opcion;
            do {
                System.out.println("\n¿Desea repetir actividad?");
                System.out.println("1. Si");
                System.out.println("2. No");
                System.out.println("3. Salir");
                opcion= opciones.nextInt();

                switch (opcion){
                    case 1:
                        OperacionesBasicas.División(args);
                        break;
                    case 2:
                        main(args);
                        break;
                    case 3:
                        System.out.println("Acción finalizada");
                        System.exit(0);
                        break;
                    default:
                        System.out.println("Ingresa una opcion valida");
                        RepetirAccion.RepeatDiv(args);
                }
            }while (opcion!=3);
            System.out.println("¡Opcion invalida!");
        }
        public static void RepeatTimer(String[] args) throws InterruptedException {
            Scanner opciones = new Scanner(System.in);
            int opcion;
            do {
                System.out.println("\n¿Desea repetir actividad?");
                System.out.println("1. Si");
                System.out.println("2. No");
                System.out.println("3. Salir");
                opcion= opciones.nextInt();

                switch (opcion){
                    case 1:
                        Acciones.Timer(args);
                        break;
                    case 2:
                        main(args);
                        break;
                    case 3:
                        System.out.println("Acción finalizada");
                        System.exit(0);
                        break;
                    default:
                        System.out.println("Ingresa una opcion valida");
                        RepetirAccion.RepeatTimer(args);
                }
            }while (opcion!=3);
            System.out.println("¡Opcion invalida!");
        }
        public static void RepeatCrono(String[] args) throws InterruptedException {
            Scanner opciones = new Scanner(System.in);
            int opcion;
            do {
                System.out.println("\n¿Desea repetir actividad?");
                System.out.println("1. Si");
                System.out.println("2. No");
                System.out.println("3. Salir");
                opcion= opciones.nextInt();

                switch (opcion){
                    case 1:
                        Acciones.Cronometro(args);
                        break;
                    case 2:
                        main(args);
                        break;
                    case 3:
                        System.out.println("Acción finalizada");
                        System.exit(0);
                        break;
                    default:
                        System.out.println("Ingresa una opcion valida");
                        RepetirAccion.RepeatCrono(args);
                }
            }while (opcion!=3);
            System.out.println("¡Opcion invalida!");
        }
        public static void RepeatContador(String[] args) throws InterruptedException {
            Scanner opciones = new Scanner(System.in);
            int opcion;
            do {
                System.out.println("\n¿Desea repetir actividad?");
                System.out.println("1. Si");
                System.out.println("2. No");
                System.out.println("3. Salir");
                opcion= opciones.nextInt();

                switch (opcion){
                    case 1:
                        Acciones.ContadorLetras(args);
                        break;
                    case 2:
                        main(args);
                        break;
                    case 3:
                        System.out.println("Acción finalizada");
                        System.exit(0);
                        break;
                    default:
                        System.out.println("Ingresa una opcion valida");
                        RepetirAccion.RepeatContador(args);
                }
            }while (opcion!=3);
            System.out.println("¡Opcion invalida!");
        }
        public static void RepeatActividadA(String[] args) throws InterruptedException {
            Scanner opciones = new Scanner(System.in);
            int opcion;
            do {
                System.out.println("\n¿Desea repetir actividad?");
                System.out.println("1. Si");
                System.out.println("2. No");
                System.out.println("3. Salir");
                opcion= opciones.nextInt();

                switch (opcion){
                    case 1:
                        Acciones.ActividadAnterior(args);
                        break;
                    case 2:
                        main(args);
                        break;
                    case 3:
                        System.out.println("Acción finalizada");
                        System.exit(0);
                        break;
                    default:
                        System.out.println("Ingresa una opcion valida");
                        RepetirAccion.RepeatActividadA(args);
                }
            }while (opcion!=3);
            System.out.println("¡Opcion invalida!");
        }
    }
}